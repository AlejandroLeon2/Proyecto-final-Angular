export const environment = {
  apiURL: 'https://proyecto-final-api-ecommerce-production.up.railway.app/v1',
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyAUcA7_gjFtiBixVvO2fL30t6Ko3my48fk',
    authDomain: 'proyecto-final-ecommerce-56d99.firebaseapp.com',
    projectId: 'proyecto-final-ecommerce-56d99',
    storageBucket: 'proyecto-final-ecommerce-56d99.firebasestorage.app',
    messagingSenderId: '870862791397',
    appId: '1:870862791397:web:e0feebea99d93bcbd0ea0c',
  },
};
