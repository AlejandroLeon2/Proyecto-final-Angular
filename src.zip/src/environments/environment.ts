export const environment = {
  apiURL: 'https://proyecto-final-api-ecommerce-production.up.railway.app/v1',
};
