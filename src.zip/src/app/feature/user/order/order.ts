import { Component } from '@angular/core';

@Component({
  selector: 'app-ordenes',
  imports: [],
  templateUrl: './order.html',
  styleUrl: './order.css',
})
export class Order {

}
